chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({
    enabled:true, mode:'words', minLength:3, minNumDigits:1, minOccurrences:2,
    wColor:'#FFD700', nColor:'#7EB8F7', tColor:'#000000',
    ignoreDates:true, ignoreTimes:true, ignoreCommon:true, caseSensitive:false,
    dateFmts:['DD/MM/YY','DD/MM/YYYY','YYYY-MM-DD','MM-DD-YYYY'],
    timeFmts:['HH:MM:SS','HH:MM','H:MM AM/PM']
  });
  chrome.contextMenus.create({id:'dwh',title:'Toggle WMNWR DupliLite',contexts:['page']});
});
chrome.contextMenus.onClicked.addListener((_,tab) => {
  chrome.storage.sync.get({enabled:true}, ({enabled}) => {
    const next = !enabled;
    chrome.storage.sync.set({enabled:next});
    chrome.tabs.sendMessage(tab.id, {type:'SET', s:{enabled:next}});
  });
});

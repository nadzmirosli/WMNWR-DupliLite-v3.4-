'use strict';
const $=id=>document.getElementById(id);
const DEF={
  enabled:true,mode:'words',minLength:3,minNumDigits:1,minOccurrences:2,
  wColor:'#FFD700',nColor:'#7EB8F7',tColor:'#000000',
  ignoreDates:true,ignoreTimes:true,ignoreCommon:true,caseSensitive:false,
  dateFmts:['DD/MM/YY','DD/MM/YYYY','YYYY-MM-DD','MM-DD-YYYY'],
  timeFmts:['HH:MM:SS','HH:MM','H:MM AM/PM']
};

let mode='words', dateFmts=[...DEF.dateFmts], timeFmts=[...DEF.timeFmts];

function tagInput(containerId, arr, onChange) {
  const box=$(containerId);
  const inp=document.createElement('input');
  inp.className='tinp'; inp.placeholder='add format…';
  box.appendChild(inp);
  function render(){
    box.querySelectorAll('.tag').forEach(t=>t.remove());
    arr.forEach((v,i)=>{
      const t=document.createElement('span'); t.className='tag';
      t.innerHTML=`${v}<span class="tx2" data-i="${i}">×</span>`;
      box.insertBefore(t,inp);
    });
    box.querySelectorAll('.tx2').forEach(x=>x.onclick=()=>{arr.splice(+x.dataset.i,1);render();onChange();});
  }
  inp.onkeydown=e=>{
    if((e.key==='Enter'||e.key===',')&&inp.value.trim()){
      e.preventDefault();
      const v=inp.value.trim().replace(/,$/,'');
      if(v&&!arr.includes(v)){arr.push(v);render();onChange();}
      inp.value='';
    }
    if(e.key==='Backspace'&&!inp.value&&arr.length){arr.pop();render();onChange();}
  };
  box.onclick=()=>inp.focus();
  render();
  return render;
}

function preview(){
  const wc=$('wc').value,nc=$('nc').value,tc=$('tc').value;
  $('pw').style.cssText=`background:${wc};color:${tc};padding:1px 5px;border-radius:2px;font-weight:500`;
  $('pn').style.cssText=`background:${nc};color:${tc};padding:1px 5px;border-radius:2px;font-weight:500`;
}
function setMode(m){mode=m;document.querySelectorAll('.mode').forEach(b=>b.classList.toggle('on',b.dataset.m===m));}
function showFmt(){
  $('dfmt').classList.toggle('show',$('id').checked);
  $('tfmt').classList.toggle('show',$('it').checked);
}
function getCfg(){
  return{enabled:$('en').checked,mode,minLength:+$('ml').value,minNumDigits:+$('md').value,
    minOccurrences:+$('mo').value,wColor:$('wc').value,nColor:$('nc').value,tColor:$('tc').value,
    ignoreDates:$('id').checked,ignoreTimes:$('it').checked,ignoreCommon:$('ic').checked,
    caseSensitive:$('cs').checked,dateFmts:[...dateFmts],timeFmts:[...timeFmts]};
}
function apply(){
  const s=getCfg();
  chrome.storage.sync.set(s);
  chrome.tabs.query({active:true,currentWindow:true},tabs=>{
    if(tabs[0]) chrome.tabs.sendMessage(tabs[0].id,{type:'SET',s}).catch(()=>{});
  });
}
function stats(){
  chrome.tabs.query({active:true,currentWindow:true},tabs=>{
    if(!tabs[0]) return;
    chrome.tabs.sendMessage(tabs[0].id,{type:'GETSTATS'},()=>chrome.runtime.lastError);
  });
}

const rD=tagInput('dtags',dateFmts,apply);
const rT=tagInput('ttags',timeFmts,apply);

chrome.storage.sync.get(DEF,s=>{
  $('en').checked=s.enabled; setMode(s.mode||'words');
  $('ml').value=s.minLength; $('vl').textContent=s.minLength;
  $('md').value=s.minNumDigits||1; $('vd').textContent=s.minNumDigits||1;
  $('mo').value=s.minOccurrences; $('vo').textContent=s.minOccurrences;
  $('wc').value=s.wColor||'#FFD700'; $('nc').value=s.nColor||'#7EB8F7'; $('tc').value=s.tColor||'#000000';
  $('id').checked=s.ignoreDates; $('it').checked=s.ignoreTimes;
  $('ic').checked=s.ignoreCommon; $('cs').checked=s.caseSensitive;
  dateFmts.length=0; dateFmts.push(...(s.dateFmts||DEF.dateFmts)); rD();
  timeFmts.length=0; timeFmts.push(...(s.timeFmts||DEF.timeFmts)); rT();
  showFmt(); preview(); setTimeout(stats,350);
});

document.querySelectorAll('.mode').forEach(b=>b.addEventListener('click',()=>{setMode(b.dataset.m);apply();}));
$('en').onchange=apply;
[['ml','vl'],['md','vd'],['mo','vo']].forEach(([id,vid])=>$(id).oninput=()=>{$(vid).textContent=$(id).value;apply();});
['wc','nc','tc'].forEach(id=>$(id).oninput=()=>{preview();apply();});
['id','it','ic','cs'].forEach(id=>$(id).onchange=()=>{showFmt();apply();});
$('scan').onclick=()=>{
  $('st2').textContent='Scanning…';
  chrome.tabs.query({active:true,currentWindow:true},tabs=>{
    if(!tabs[0]) return;
    chrome.tabs.sendMessage(tabs[0].id,{type:'SCAN'});
    setTimeout(()=>{stats();$('st2').textContent='✓';setTimeout(()=>$('st2').textContent='',1800);},1200);
  });
};
chrome.runtime.onMessage.addListener(msg=>{
  if(msg.type==='STATS'){$('st').textContent=msg.total;$('sw').textContent=msg.uw;$('sn').textContent=msg.un;}
});

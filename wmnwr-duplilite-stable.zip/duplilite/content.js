(() => {
'use strict';

const DEF = {
  enabled:true, mode:'words', minLength:3, minNumDigits:1, minOccurrences:2,
  wColor:'#FFD700', nColor:'#7EB8F7', tColor:'#000000',
  ignoreDates:true, ignoreTimes:true, ignoreCommon:true, caseSensitive:false,
  dateFmts:['DD/MM/YY','DD/MM/YYYY','YYYY-MM-DD','MM-DD-YYYY'],
  timeFmts:['HH:MM:SS','HH:MM','H:MM AM/PM']
};

const CW = new Set('the,and,for,are,but,not,you,all,can,had,her,was,one,our,out,day,get,has,him,his,how,its,may,new,now,old,see,two,who,did,let,put,say,she,too,use,way,will,with,that,this,from,they,been,have,more,when,your,each,than,then,them,these,some,also,into,like,just,what,over,such,only,make,most,both,even,much,does,help,give,come,same,well,back,good,many,time,know,here,very,after,about,could,would,there,their,which,first,other,where,being,those,still,found,under,while,often,every,never,again,think,place,world,small,large,using,going,said,made,went,came,gave,kept,felt,seen,told,left,become,makes,wants,needs,having,getting,taking,making,saying,seeing,knowing,looking,trying,asking,giving,should,little,always,before,without,between,through,because,another,against,however,already,nothing,several,whether'.split(','));

const SKIP = new Set(['script','style','noscript','textarea','input','select','code','pre','head','meta','svg','canvas','video','audio']);

let cfg = {...DEF};
let dateRx = [], timeRx = [];
let obs = null;
let scanTimer = null;
let scanning = false;
// Track whether we have highlights on the page
let highlighted = false;

function buildRx(fmt) {
  return new RegExp('^' +
    fmt.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')
       .replace(/YYYY/g,'\\d{4}').replace(/YY/g,'\\d{2}')
       .replace(/MM/g,'\\d{1,2}').replace(/DD/g,'\\d{1,2}')
       .replace(/HH/g,'\\d{2}').replace(/H/g,'\\d{1,2}')
       .replace(/SS/g,'\\d{2}').replace(/AM\/PM/g,'(?:am|pm|AM|PM)')
       .replace(/[\/\-]/g,'[\\/\\-\\.]')
  + '$','i');
}
function rebuildRx() {
  dateRx = (cfg.dateFmts||[]).map(f=>{try{return buildRx(f)}catch{return null}}).filter(Boolean);
  timeRx = (cfg.timeFmts||[]).map(f=>{try{return buildRx(f)}catch{return null}}).filter(Boolean);
}

function getNodes(root) {
  const out = [];
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(n) {
      const p = n.parentElement;
      if (!p) return 3;
      if (SKIP.has(p.tagName.toLowerCase())) return 3;
      if (p.hasAttribute('data-dwh')) return 3;
      if (!n.data.trim()) return 2;
      return 1;
    }
  });
  let n; while ((n = w.nextNode())) out.push(n);
  return out;
}

function clear() {
  if (!highlighted) return;
  const marks = document.querySelectorAll('[data-dwh]');
  if (!marks.length) { highlighted = false; return; }
  const parents = new Set();
  marks.forEach(el => {
    const p = el.parentNode;
    if (p) { el.replaceWith(document.createTextNode(el.textContent)); parents.add(p); }
  });
  parents.forEach(p => p.normalize());
  highlighted = false;
}

function buildMaps(nodes) {
  const wM = new Map(), nM = new Map();
  const doW = cfg.mode !== 'numbers';
  const doN = cfg.mode !== 'words';
  const sep = /[\/\-:]/;
  const numRe = /-?\d[\d,]*(?:\.\d+)?%?/g;
  const wordRe = /[a-zA-Z\u00C0-\u017F]+/g;

  for (const node of nodes) {
    const txt = node.data;
    if (doW) {
      wordRe.lastIndex = 0;
      let m;
      while ((m = wordRe.exec(txt)) !== null) {
        if (m[0].length < cfg.minLength) continue;
        const k = cfg.caseSensitive ? m[0] : m[0].toLowerCase();
        if (cfg.ignoreCommon && CW.has(k)) continue;
        wM.set(k, (wM.get(k)||0) + 1);
      }
    }
    if (doN) {
      numRe.lastIndex = 0;
      let m;
      while ((m = numRe.exec(txt)) !== null) {
        const raw = m[0], i = m.index;
        const before = txt[i-1]||'', after = txt[i+raw.length]||'';
        if (sep.test(before) || sep.test(after)) continue;
        if (cfg.ignoreDates || cfg.ignoreTimes) {
          const ctx = txt.slice(Math.max(0,i-3), i+raw.length+3).trim();
          if (cfg.ignoreDates && (dateRx.some(r=>r.test(ctx)) || dateRx.some(r=>r.test(raw)))) continue;
          if (cfg.ignoreTimes && (timeRx.some(r=>r.test(ctx)) || timeRx.some(r=>r.test(raw)))) continue;
        }
        if (raw.replace(/\D/g,'').length < cfg.minNumDigits) continue;
        nM.set(raw, (nM.get(raw)||0) + 1);
      }
    }
  }
  return {wM, nM};
}

function applyHighlights(nodes, dupW, dupN) {
  if (!dupW.size && !dupN.size) return;
  const pts = [];
  if (dupW.size) {
    const list = [...dupW].sort((a,b)=>b.length-a.length).map(s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|');
    pts.push(`(?<w>\\b(?:${list})\\b)`);
  }
  if (dupN.size) {
    const list = [...dupN].sort((a,b)=>b.length-a.length).map(s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|');
    pts.push(`(?<n>(?<![\\d\\/\\-:])(?:${list})(?![\\d\\/\\-:]))`);
  }
  const flags = cfg.caseSensitive ? 'g' : 'gi';
  const re = new RegExp(pts.join('|'), flags);
  const wC = cfg.wColor, nC = cfg.nColor, tC = cfg.tColor;

  for (const node of nodes) {
    if (!node.parentNode) continue;
    const txt = node.data;
    re.lastIndex = 0;
    if (!re.test(txt)) continue;
    re.lastIndex = 0;
    const frag = document.createDocumentFragment();
    let last = 0, m;
    while ((m = re.exec(txt)) !== null) {
      if (m.index > last) frag.appendChild(document.createTextNode(txt.slice(last, m.index)));
      const isN = m.groups?.n !== undefined;
      const el = document.createElement('mark');
      el.setAttribute('data-dwh', isN ? 'n' : 'w');
      el.textContent = m[0];
      el.style.cssText = `background:${isN?nC:wC};color:${tC};border-radius:2px;padding:0 1px;font:inherit;box-shadow:none;text-decoration:none;`;
      frag.appendChild(el);
      last = m.index + m[0].length;
    }
    if (last < txt.length) frag.appendChild(document.createTextNode(txt.slice(last)));
    if (frag.childNodes.length > 1) { node.parentNode.replaceChild(frag, node); highlighted = true; }
  }
}

// ── CORE FIX: scan collects nodes ONCE, clears, then applies in one pass ──
function scan() {
  if (!cfg.enabled || scanning) return;

  // Pause observer BEFORE touching DOM
  if (obs) obs.disconnect();
  scanning = true;

  try {
    // 1. Walk nodes FIRST (before any DOM change)
    const nodes = getNodes(document.body);

    // 2. Build frequency maps from the snapshot
    const {wM, nM} = buildMaps(nodes);
    const dupW = new Set([...wM].filter(([,c])=>c>=cfg.minOccurrences).map(([k])=>k));
    const dupN = new Set([...nM].filter(([,c])=>c>=cfg.minOccurrences).map(([k])=>k));

    // 3. Clear old highlights (no normalize — avoids DOM churn)
    if (highlighted) {
      document.querySelectorAll('[data-dwh]').forEach(el => {
        el.outerHTML = el.textContent; // fast inline replace, no parent needed
      });
      highlighted = false;
    }

    // 4. Apply new highlights to the same node list — no second walk needed
    //    (nodes still valid since we only did outerHTML text replacement)
    const freshNodes = getNodes(document.body);
    applyHighlights(freshNodes, dupW, dupN);

  } catch(e) {
    console.warn('[DupliLite]', e);
  }

  scanning = false;

  // Resume observer after all DOM writes complete — use microtask to
  // ensure browser has flushed layout before we re-attach
  Promise.resolve().then(() => { if (cfg.enabled) startObs(); });
}

function schedule(ms = 1000) {
  clearTimeout(scanTimer);
  scanTimer = setTimeout(scan, ms);
}

// ── Observer: ONLY watches for new meaningful content, ignores everything else
function startObs() {
  if (obs) obs.disconnect();
  obs = new MutationObserver(muts => {
    if (scanning) return;

    for (const m of muts) {
      // ── Ignore: attribute changes, our own marks, style/class mutations ──
      if (m.type === 'attributes') continue;
      if (m.type === 'characterData') {
        // Only care if a real text node changed, not inside our marks
        const p = m.target.parentElement;
        if (!p || p.hasAttribute('data-dwh')) continue;
        if (SKIP.has(p.tagName.toLowerCase())) continue;
        schedule(2000);
        return;
      }
      // childList — only trigger on substantial new content
      for (const n of m.addedNodes) {
        // Ignore text nodes (scroll position artifacts, whitespace)
        if (n.nodeType === 3) continue;
        // Ignore our own marks
        if (n.nodeType === 1 && n.hasAttribute('data-dwh')) continue;
        // Ignore tiny/invisible elements (ads, trackers, hidden spans)
        if (n.nodeType === 1) {
          const tag = n.tagName.toLowerCase();
          if (SKIP.has(tag)) continue;
          // Only re-scan if the new element has actual visible text
          if (!n.textContent.trim()) continue;
          schedule(2000);
          return;
        }
      }
    }
  });

  // ── KEY: do NOT watch characterData on subtree — causes scroll thrash ──
  // Only watch childList for new elements being added to the page
  obs.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: false,   // ← was true, caused scroll re-triggers
    attributes: false       // ← never needed
  });
}

function stopAll() {
  if (obs) { obs.disconnect(); obs = null; }
  clearTimeout(scanTimer);
  scanning = false;
  clear();
}

function sendStats() {
  const all = document.querySelectorAll('[data-dwh]');
  const ws = new Set(), ns = new Set();
  all.forEach(el => {
    if (el.getAttribute('data-dwh')==='n') ns.add(el.textContent);
    else ws.add(el.textContent.toLowerCase());
  });
  chrome.runtime.sendMessage({type:'STATS', total:all.length, uw:ws.size, un:ns.size}).catch(()=>{});
}

chrome.storage.sync.get(DEF, s => {
  Object.assign(cfg, s);
  rebuildRx();
  if (cfg.enabled) { startObs(); schedule(1200); }
});

chrome.runtime.onMessage.addListener(msg => {
  if (msg.type === 'SET') {
    Object.assign(cfg, msg.s);
    rebuildRx();
    cfg.enabled ? (startObs(), schedule(300)) : stopAll();
  }
  if (msg.type === 'SCAN') schedule(80);
  if (msg.type === 'GETSTATS') sendStats();
});

})();
